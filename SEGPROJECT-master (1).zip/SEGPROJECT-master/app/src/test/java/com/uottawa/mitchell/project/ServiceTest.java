package com.uottawa.mitchell.project;

import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

public class ServiceTest{

    Service service = new Service("ServiceName","ServiceType",100L );

    @Test
    public void testServiceName(){
        String in = "ServiceName1";
        String out= service.getName();
        String expected = "ServiceName";
        assertNotEquals(in,out);
    }

    @Test
    public void testServiceType(){
        String in = "ServiceType1";
        String out= service.getType();
        String expected = "ServiceType";
        assertNotEquals(in,out);
    }

    @Test
    public void testRate(){
        Long in = 110L;
        Long out=service.getHourlyrate();
        Long expected = 100L;
        assertNotEquals(in,out);
    }


}
