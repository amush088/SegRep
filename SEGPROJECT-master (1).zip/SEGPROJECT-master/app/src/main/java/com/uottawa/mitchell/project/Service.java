package com.uottawa.mitchell.project;

public class Service {
    private String name;
    private String type;
    private Long hourlyrate;
    public Service (String name, String type, Long hourlyrate) {
        this.name=name;
        this.type=type;
        this.hourlyrate=hourlyrate;
    }


    public Long getHourlyrate (){
        return hourlyrate;
    }
    public String getName (){
        return name;
    }
    public String getType (){
        return type;
    }
    public String toString  (){
        return (name+": "+type+": "+hourlyrate);
    }
}
