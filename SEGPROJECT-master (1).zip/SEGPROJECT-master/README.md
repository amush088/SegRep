# SEG_PROJ
Link to repository - https://github.com/BillalZazai/SEGPROJECT/

Group members:

Billal Zazai--8572975

Aidan O'Connor -- 8666650

Alex Mushyirahamwe -- 8677283

Mitchell Chatterjee -- 8598617

Kenny Nguyen -- 8642034


***** IMPORTANT
Please note that admin is not an acceptable username in this implementation nor is the password admin. Therefore the admin username is admin@gmail.com and the admin password is admin12.
